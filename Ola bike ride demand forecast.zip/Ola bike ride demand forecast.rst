.. code:: ipython3

    import numpy as np
    import pandas as pd

.. code:: ipython3

    train_df=pd.read_csv('C:/Users/vaish/OneDrive/Desktop/projects/train.csv')
    test_df=pd.read_csv('C:/Users/vaish/OneDrive/Desktop/projects/test.csv')
    sampleSubmission_df=pd.read_csv('C:/Users/vaish/OneDrive/Desktop/projects/sampleSubmission.csv')

.. code:: ipython3

    train_df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>datetime</th>
          <th>season</th>
          <th>holiday</th>
          <th>workingday</th>
          <th>weather</th>
          <th>temp</th>
          <th>atemp</th>
          <th>humidity</th>
          <th>windspeed</th>
          <th>casual</th>
          <th>registered</th>
          <th>count</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2011-01-01 00:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>81</td>
          <td>0.0</td>
          <td>3</td>
          <td>13</td>
          <td>16</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2011-01-01 01:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.02</td>
          <td>13.635</td>
          <td>80</td>
          <td>0.0</td>
          <td>8</td>
          <td>32</td>
          <td>40</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2011-01-01 02:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.02</td>
          <td>13.635</td>
          <td>80</td>
          <td>0.0</td>
          <td>5</td>
          <td>27</td>
          <td>32</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2011-01-01 03:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>75</td>
          <td>0.0</td>
          <td>3</td>
          <td>10</td>
          <td>13</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2011-01-01 04:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>75</td>
          <td>0.0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    test_df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>datetime</th>
          <th>season</th>
          <th>holiday</th>
          <th>workingday</th>
          <th>weather</th>
          <th>temp</th>
          <th>atemp</th>
          <th>humidity</th>
          <th>windspeed</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2011-01-20 00:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>10.66</td>
          <td>11.365</td>
          <td>56</td>
          <td>26.0027</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2011-01-20 01:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>10.66</td>
          <td>13.635</td>
          <td>56</td>
          <td>0.0000</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2011-01-20 02:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>10.66</td>
          <td>13.635</td>
          <td>56</td>
          <td>0.0000</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2011-01-20 03:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>10.66</td>
          <td>12.880</td>
          <td>56</td>
          <td>11.0014</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2011-01-20 04:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>10.66</td>
          <td>12.880</td>
          <td>56</td>
          <td>11.0014</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    print(train_df.shape)
    print(test_df.shape)


.. parsed-literal::

    (10886, 12)
    (6493, 9)
    

.. code:: ipython3

    test_df.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 6493 entries, 0 to 6492
    Data columns (total 9 columns):
     #   Column      Non-Null Count  Dtype  
    ---  ------      --------------  -----  
     0   datetime    6493 non-null   object 
     1   season      6493 non-null   int64  
     2   holiday     6493 non-null   int64  
     3   workingday  6493 non-null   int64  
     4   weather     6493 non-null   int64  
     5   temp        6493 non-null   float64
     6   atemp       6493 non-null   float64
     7   humidity    6493 non-null   int64  
     8   windspeed   6493 non-null   float64
    dtypes: float64(3), int64(5), object(1)
    memory usage: 456.7+ KB
    

.. code:: ipython3

    train_df.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 10886 entries, 0 to 10885
    Data columns (total 12 columns):
     #   Column      Non-Null Count  Dtype  
    ---  ------      --------------  -----  
     0   datetime    10886 non-null  object 
     1   season      10886 non-null  int64  
     2   holiday     10886 non-null  int64  
     3   workingday  10886 non-null  int64  
     4   weather     10886 non-null  int64  
     5   temp        10886 non-null  float64
     6   atemp       10886 non-null  float64
     7   humidity    10886 non-null  int64  
     8   windspeed   10886 non-null  float64
     9   casual      10886 non-null  int64  
     10  registered  10886 non-null  int64  
     11  count       10886 non-null  int64  
    dtypes: float64(3), int64(8), object(1)
    memory usage: 1020.7+ KB
    

.. code:: ipython3

    train_df['date'] = train_df['datetime'].apply(lambda x: x.split()[0])

.. code:: ipython3

    train_df['year'] = train_df['datetime'].apply(lambda x: x.split()[0].split('-')[0])
    train_df['month'] = train_df['datetime'].apply(lambda x: x.split()[0].split('-')[1])
    train_df['day'] = train_df['datetime'].apply(lambda x: x.split()[0].split('-')[2])
    train_df['hour'] = train_df['datetime'].apply(lambda x: x.split()[1].split(':')[0])
    # train_df['minute'] = train_df['datetime'].apply(lambda x: x.split()[1].split(':')[1])
    # train_df['second'] = train_df['datetime'].apply(lambda x: x.split()[1].split(':')[2])

.. code:: ipython3

    from datetime import datetime
    import calendar

.. code:: ipython3

    train_df['weekday'] = train_df['date'].apply(lambda dateString: calendar.day_name[datetime.strptime(dateString, "%Y-%m-%d").weekday()])

.. code:: ipython3

    train_df['encoded_season'] = train_df['season'].map({
        1: 'Spring',
        2: 'Summer',
        3: 'Fall',
        4: 'Winter'
    })
    train_df['encoded_weather'] = train_df['weather'].map({
        1: 'Clear',
        2: 'Mist, Few clouds',
        3: 'Light Snow, Rain, Thunderstorm',
        4: 'Heavy Rain, Thunderstorm, Snow, Fog'
    })

.. code:: ipython3

    train_df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>datetime</th>
          <th>season</th>
          <th>holiday</th>
          <th>workingday</th>
          <th>weather</th>
          <th>temp</th>
          <th>atemp</th>
          <th>humidity</th>
          <th>windspeed</th>
          <th>casual</th>
          <th>registered</th>
          <th>count</th>
          <th>date</th>
          <th>year</th>
          <th>month</th>
          <th>day</th>
          <th>hour</th>
          <th>weekday</th>
          <th>encoded_season</th>
          <th>encoded_weather</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2011-01-01 00:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>81</td>
          <td>0.0</td>
          <td>3</td>
          <td>13</td>
          <td>16</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>00</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2011-01-01 01:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.02</td>
          <td>13.635</td>
          <td>80</td>
          <td>0.0</td>
          <td>8</td>
          <td>32</td>
          <td>40</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>01</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2011-01-01 02:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.02</td>
          <td>13.635</td>
          <td>80</td>
          <td>0.0</td>
          <td>5</td>
          <td>27</td>
          <td>32</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>02</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2011-01-01 03:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>75</td>
          <td>0.0</td>
          <td>3</td>
          <td>10</td>
          <td>13</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>03</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2011-01-01 04:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>75</td>
          <td>0.0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>04</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    import seaborn as sns
    import matplotlib as mpl
    import matplotlib.pyplot as plt

.. code:: ipython3

    sns.displot(train_df['count'])




.. parsed-literal::

    <seaborn.axisgrid.FacetGrid at 0x1d36ab3ba10>




.. image:: output_14_1.png


.. code:: ipython3

    sns.displot(np.log(train_df['count']))




.. parsed-literal::

    <seaborn.axisgrid.FacetGrid at 0x1d365d33ad0>




.. image:: output_15_1.png


.. code:: ipython3

    figure, axes = plt.subplots(nrows=2, ncols=2)
    figure.set_size_inches(10, 9)
    plt.tight_layout()
    
    sns.barplot(x='year', y='count', data=train_df, ax=axes[0, 0])
    sns.barplot(x='month', y='count', data=train_df, ax=axes[0, 1])
    sns.barplot(x='day', y='count', data=train_df, ax=axes[1, 0])
    sns.barplot(x='hour', y='count', data=train_df, ax=axes[1,1])




.. parsed-literal::

    <Axes: xlabel='hour', ylabel='count'>




.. image:: output_16_1.png


.. code:: ipython3

    figure, axes = plt.subplots(nrows=2, ncols=2)
    figure.set_size_inches(10, 10)
    plt.tight_layout()
    
    sns.boxplot(x='encoded_season', y='count', data=train_df, ax=axes[0, 0])
    sns.boxplot(x='encoded_weather', y='count', data=train_df, ax=axes[0, 1])
    sns.boxplot(x='holiday', y='count', data=train_df, ax=axes[1, 0])
    sns.boxplot(x='workingday', y='count', data=train_df, ax=axes[1,1])
    plt.show()



.. image:: output_17_0.png


.. code:: ipython3

    figure, axes = plt.subplots(nrows=5)
    figure.set_size_inches(12, 18)
    
    sns.pointplot(x='hour', y='count', data=train_df, hue='workingday', ax=axes[0])
    sns.pointplot(x='hour', y='count', data=train_df, hue='holiday', ax=axes[1])
    sns.pointplot(x='hour', y='count', data=train_df, hue='weekday', ax=axes[2])
    sns.pointplot(x='hour', y='count', data=train_df, hue='encoded_season', ax=axes[3])
    sns.pointplot(x='hour', y='count', data=train_df, hue='encoded_weather', ax=axes[4])




.. parsed-literal::

    <Axes: xlabel='hour', ylabel='count'>




.. image:: output_18_1.png


.. code:: ipython3

    figure, axes = plt.subplots(nrows=2, ncols=2)
    figure.set_size_inches(7, 6)
    plt.tight_layout()
    
    sns.regplot(x='temp', y='count', data=train_df, ax=axes[0, 0], scatter_kws={'alpha': 0.1}, line_kws={'color': 'blue'})
    sns.regplot(x='atemp', y='count', data=train_df, ax=axes[0, 1], scatter_kws={'alpha': 0.1}, line_kws={'color': 'blue'})
    sns.regplot(x='windspeed', y='count', data=train_df, ax=axes[1, 0], scatter_kws={'alpha': 0.1}, line_kws={'color': 'blue'})
    sns.regplot(x='humidity', y='count', data=train_df, ax=axes[1, 1], scatter_kws={'alpha': 0.1}, line_kws={'color':'blue'})
    




.. parsed-literal::

    <Axes: xlabel='humidity', ylabel='count'>




.. image:: output_19_1.png


.. code:: ipython3

    corr = train_df[['temp', 'atemp', 'humidity', 'windspeed', 'count']].corr()

.. code:: ipython3

    fig, ax = plt.subplots()
    fig.set_size_inches(5,4)
    sns.heatmap(corr, annot=True)




.. parsed-literal::

    <Axes: >




.. image:: output_21_1.png


.. code:: ipython3

    all_df = pd.concat([train_df, test_df], ignore_index=True)
    all_df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>datetime</th>
          <th>season</th>
          <th>holiday</th>
          <th>workingday</th>
          <th>weather</th>
          <th>temp</th>
          <th>atemp</th>
          <th>humidity</th>
          <th>windspeed</th>
          <th>casual</th>
          <th>registered</th>
          <th>count</th>
          <th>date</th>
          <th>year</th>
          <th>month</th>
          <th>day</th>
          <th>hour</th>
          <th>weekday</th>
          <th>encoded_season</th>
          <th>encoded_weather</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2011-01-01 00:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>81</td>
          <td>0.0</td>
          <td>3.0</td>
          <td>13.0</td>
          <td>16.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>00</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2011-01-01 01:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.02</td>
          <td>13.635</td>
          <td>80</td>
          <td>0.0</td>
          <td>8.0</td>
          <td>32.0</td>
          <td>40.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>01</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2011-01-01 02:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.02</td>
          <td>13.635</td>
          <td>80</td>
          <td>0.0</td>
          <td>5.0</td>
          <td>27.0</td>
          <td>32.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>02</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2011-01-01 03:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>75</td>
          <td>0.0</td>
          <td>3.0</td>
          <td>10.0</td>
          <td>13.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>03</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2011-01-01 04:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>75</td>
          <td>0.0</td>
          <td>0.0</td>
          <td>1.0</td>
          <td>1.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>04</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    all_df.isnull().sum()




.. parsed-literal::

    datetime              0
    season                0
    holiday               0
    workingday            0
    weather               0
    temp                  0
    atemp                 0
    humidity              0
    windspeed             0
    casual             6493
    registered         6493
    count              6493
    date               6493
    year               6493
    month              6493
    day                6493
    hour               6493
    weekday            6493
    encoded_season     6493
    encoded_weather    6493
    dtype: int64



.. code:: ipython3

    all_df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>datetime</th>
          <th>season</th>
          <th>holiday</th>
          <th>workingday</th>
          <th>weather</th>
          <th>temp</th>
          <th>atemp</th>
          <th>humidity</th>
          <th>windspeed</th>
          <th>casual</th>
          <th>registered</th>
          <th>count</th>
          <th>date</th>
          <th>year</th>
          <th>month</th>
          <th>day</th>
          <th>hour</th>
          <th>weekday</th>
          <th>encoded_season</th>
          <th>encoded_weather</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2011-01-01 00:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>81</td>
          <td>0.0</td>
          <td>3.0</td>
          <td>13.0</td>
          <td>16.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>00</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2011-01-01 01:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.02</td>
          <td>13.635</td>
          <td>80</td>
          <td>0.0</td>
          <td>8.0</td>
          <td>32.0</td>
          <td>40.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>01</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2011-01-01 02:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.02</td>
          <td>13.635</td>
          <td>80</td>
          <td>0.0</td>
          <td>5.0</td>
          <td>27.0</td>
          <td>32.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>02</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2011-01-01 03:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>75</td>
          <td>0.0</td>
          <td>3.0</td>
          <td>10.0</td>
          <td>13.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>03</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2011-01-01 04:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>75</td>
          <td>0.0</td>
          <td>0.0</td>
          <td>1.0</td>
          <td>1.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>04</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    all_df['date'] = all_df['datetime'].apply(lambda x: x.split()[0])
    all_df['day'] = all_df['datetime'].apply(lambda x: x.split()[0].split('-')[2])
    all_df['year'] = all_df['datetime'].apply(lambda x: x.split()[0].split('-')[0])
    all_df['month'] = all_df['datetime'].apply(lambda x: x.split()[0].split('-')[1])
    all_df['hour'] = all_df['datetime'].apply(lambda x: x.split()[1].split(':')[0])

.. code:: ipython3

    all_df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>datetime</th>
          <th>season</th>
          <th>holiday</th>
          <th>workingday</th>
          <th>weather</th>
          <th>temp</th>
          <th>atemp</th>
          <th>humidity</th>
          <th>windspeed</th>
          <th>casual</th>
          <th>registered</th>
          <th>count</th>
          <th>date</th>
          <th>year</th>
          <th>month</th>
          <th>day</th>
          <th>hour</th>
          <th>weekday</th>
          <th>encoded_season</th>
          <th>encoded_weather</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2011-01-01 00:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>81</td>
          <td>0.0</td>
          <td>3.0</td>
          <td>13.0</td>
          <td>16.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>00</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2011-01-01 01:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.02</td>
          <td>13.635</td>
          <td>80</td>
          <td>0.0</td>
          <td>8.0</td>
          <td>32.0</td>
          <td>40.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>01</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2011-01-01 02:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.02</td>
          <td>13.635</td>
          <td>80</td>
          <td>0.0</td>
          <td>5.0</td>
          <td>27.0</td>
          <td>32.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>02</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2011-01-01 03:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>75</td>
          <td>0.0</td>
          <td>3.0</td>
          <td>10.0</td>
          <td>13.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>03</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2011-01-01 04:00:00</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>75</td>
          <td>0.0</td>
          <td>0.0</td>
          <td>1.0</td>
          <td>1.0</td>
          <td>2011-01-01</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
          <td>04</td>
          <td>Saturday</td>
          <td>Spring</td>
          <td>Clear</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    all_df.columns




.. parsed-literal::

    Index(['datetime', 'season', 'holiday', 'workingday', 'weather', 'temp',
           'atemp', 'humidity', 'windspeed', 'casual', 'registered', 'count',
           'date', 'year', 'month', 'day', 'hour', 'weekday', 'encoded_season',
           'encoded_weather'],
          dtype='object')



.. code:: ipython3

    drop_features = ['casual', 'registered', 'datetime', 'date', 'windspeed', 'month', 'encoded_season', 'encoded_weather', 'weekday']
    all_df=all_df.drop(drop_features, axis=1)

.. code:: ipython3

    all_df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>season</th>
          <th>holiday</th>
          <th>workingday</th>
          <th>weather</th>
          <th>temp</th>
          <th>atemp</th>
          <th>humidity</th>
          <th>count</th>
          <th>year</th>
          <th>day</th>
          <th>hour</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>81</td>
          <td>16.0</td>
          <td>2011</td>
          <td>01</td>
          <td>00</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.02</td>
          <td>13.635</td>
          <td>80</td>
          <td>40.0</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.02</td>
          <td>13.635</td>
          <td>80</td>
          <td>32.0</td>
          <td>2011</td>
          <td>01</td>
          <td>02</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>75</td>
          <td>13.0</td>
          <td>2011</td>
          <td>01</td>
          <td>03</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>75</td>
          <td>1.0</td>
          <td>2011</td>
          <td>01</td>
          <td>04</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    all_df.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 17379 entries, 0 to 17378
    Data columns (total 11 columns):
     #   Column      Non-Null Count  Dtype  
    ---  ------      --------------  -----  
     0   season      17379 non-null  int64  
     1   holiday     17379 non-null  int64  
     2   workingday  17379 non-null  int64  
     3   weather     17379 non-null  int64  
     4   temp        17379 non-null  float64
     5   atemp       17379 non-null  float64
     6   humidity    17379 non-null  int64  
     7   count       10886 non-null  float64
     8   year        17379 non-null  object 
     9   day         17379 non-null  object 
     10  hour        17379 non-null  object 
    dtypes: float64(3), int64(5), object(3)
    memory usage: 1.5+ MB
    

.. code:: ipython3

    all_df.isnull().sum()




.. parsed-literal::

    season           0
    holiday          0
    workingday       0
    weather          0
    temp             0
    atemp            0
    humidity         0
    count         6493
    year             0
    day              0
    hour             0
    dtype: int64



.. code:: ipython3

    X_train = all_df[~pd.isnull(all_df['count'])]
    X_test = all_df[pd.isnull(all_df['count'])]
    
    # remove target value
    X_train = X_train.drop(['count'], axis=1)
    X_test = X_test.drop(['count'], axis=1)
    
    y_train = train_df['count']

.. code:: ipython3

    X_train.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>season</th>
          <th>holiday</th>
          <th>workingday</th>
          <th>weather</th>
          <th>temp</th>
          <th>atemp</th>
          <th>humidity</th>
          <th>year</th>
          <th>day</th>
          <th>hour</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>81</td>
          <td>2011</td>
          <td>01</td>
          <td>00</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.02</td>
          <td>13.635</td>
          <td>80</td>
          <td>2011</td>
          <td>01</td>
          <td>01</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.02</td>
          <td>13.635</td>
          <td>80</td>
          <td>2011</td>
          <td>01</td>
          <td>02</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>75</td>
          <td>2011</td>
          <td>01</td>
          <td>03</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>9.84</td>
          <td>14.395</td>
          <td>75</td>
          <td>2011</td>
          <td>01</td>
          <td>04</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    X_train.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    Index: 10886 entries, 0 to 10885
    Data columns (total 10 columns):
     #   Column      Non-Null Count  Dtype  
    ---  ------      --------------  -----  
     0   season      10886 non-null  int64  
     1   holiday     10886 non-null  int64  
     2   workingday  10886 non-null  int64  
     3   weather     10886 non-null  int64  
     4   temp        10886 non-null  float64
     5   atemp       10886 non-null  float64
     6   humidity    10886 non-null  int64  
     7   year        10886 non-null  object 
     8   day         10886 non-null  object 
     9   hour        10886 non-null  object 
    dtypes: float64(2), int64(5), object(3)
    memory usage: 935.5+ KB
    

.. code:: ipython3

    def rmsle(y_true, y_pred, convertExp=True):
        if convertExp:
            y_true = np.exp(y_true)
            y_pred = np.exp(y_pred)
            
        log_true = np.nan_to_num(np.log(y_true+1))
        log_pred = np.nan_to_num(np.log(y_pred+1))
        
        output = np.sqrt(np.mean((log_true - log_pred)**2))
        return output

.. code:: ipython3

    from sklearn.model_selection import GridSearchCV
    from sklearn import metrics

.. code:: ipython3

    from sklearn.ensemble import RandomForestRegressor
    
    model = RandomForestRegressor()

.. code:: ipython3

    rf_params = {'random_state': [42], 'n_estimators': [100, 120, 140]}
    
    rmsle_scorer = metrics.make_scorer(rmsle, greater_is_better=False)

.. code:: ipython3

    gridsearch_random_forest_model = GridSearchCV(estimator=model,
                                         param_grid=rf_params,
                                         scoring=rmsle_scorer,
                                         cv=5)

.. code:: ipython3

    log_y_train = np.log(y_train)
    gridsearch_random_forest_model.fit(X_train, log_y_train)




.. raw:: html

    <style>#sk-container-id-1 {
      /* Definition of color scheme common for light and dark mode */
      --sklearn-color-text: black;
      --sklearn-color-line: gray;
      /* Definition of color scheme for unfitted estimators */
      --sklearn-color-unfitted-level-0: #fff5e6;
      --sklearn-color-unfitted-level-1: #f6e4d2;
      --sklearn-color-unfitted-level-2: #ffe0b3;
      --sklearn-color-unfitted-level-3: chocolate;
      /* Definition of color scheme for fitted estimators */
      --sklearn-color-fitted-level-0: #f0f8ff;
      --sklearn-color-fitted-level-1: #d4ebff;
      --sklearn-color-fitted-level-2: #b3dbfd;
      --sklearn-color-fitted-level-3: cornflowerblue;
    
      /* Specific color for light theme */
      --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
      --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
      --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
      --sklearn-color-icon: #696969;
    
      @media (prefers-color-scheme: dark) {
        /* Redefinition of color scheme for dark theme */
        --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
        --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
        --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
        --sklearn-color-icon: #878787;
      }
    }
    
    #sk-container-id-1 {
      color: var(--sklearn-color-text);
    }
    
    #sk-container-id-1 pre {
      padding: 0;
    }
    
    #sk-container-id-1 input.sk-hidden--visually {
      border: 0;
      clip: rect(1px 1px 1px 1px);
      clip: rect(1px, 1px, 1px, 1px);
      height: 1px;
      margin: -1px;
      overflow: hidden;
      padding: 0;
      position: absolute;
      width: 1px;
    }
    
    #sk-container-id-1 div.sk-dashed-wrapped {
      border: 1px dashed var(--sklearn-color-line);
      margin: 0 0.4em 0.5em 0.4em;
      box-sizing: border-box;
      padding-bottom: 0.4em;
      background-color: var(--sklearn-color-background);
    }
    
    #sk-container-id-1 div.sk-container {
      /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
         but bootstrap.min.css set `[hidden] { display: none !important; }`
         so we also need the `!important` here to be able to override the
         default hidden behavior on the sphinx rendered scikit-learn.org.
         See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
      display: inline-block !important;
      position: relative;
    }
    
    #sk-container-id-1 div.sk-text-repr-fallback {
      display: none;
    }
    
    div.sk-parallel-item,
    div.sk-serial,
    div.sk-item {
      /* draw centered vertical line to link estimators */
      background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
      background-size: 2px 100%;
      background-repeat: no-repeat;
      background-position: center center;
    }
    
    /* Parallel-specific style estimator block */
    
    #sk-container-id-1 div.sk-parallel-item::after {
      content: "";
      width: 100%;
      border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
      flex-grow: 1;
    }
    
    #sk-container-id-1 div.sk-parallel {
      display: flex;
      align-items: stretch;
      justify-content: center;
      background-color: var(--sklearn-color-background);
      position: relative;
    }
    
    #sk-container-id-1 div.sk-parallel-item {
      display: flex;
      flex-direction: column;
    }
    
    #sk-container-id-1 div.sk-parallel-item:first-child::after {
      align-self: flex-end;
      width: 50%;
    }
    
    #sk-container-id-1 div.sk-parallel-item:last-child::after {
      align-self: flex-start;
      width: 50%;
    }
    
    #sk-container-id-1 div.sk-parallel-item:only-child::after {
      width: 0;
    }
    
    /* Serial-specific style estimator block */
    
    #sk-container-id-1 div.sk-serial {
      display: flex;
      flex-direction: column;
      align-items: center;
      background-color: var(--sklearn-color-background);
      padding-right: 1em;
      padding-left: 1em;
    }
    
    
    /* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
    clickable and can be expanded/collapsed.
    - Pipeline and ColumnTransformer use this feature and define the default style
    - Estimators will overwrite some part of the style using the `sk-estimator` class
    */
    
    /* Pipeline and ColumnTransformer style (default) */
    
    #sk-container-id-1 div.sk-toggleable {
      /* Default theme specific background. It is overwritten whether we have a
      specific estimator or a Pipeline/ColumnTransformer */
      background-color: var(--sklearn-color-background);
    }
    
    /* Toggleable label */
    #sk-container-id-1 label.sk-toggleable__label {
      cursor: pointer;
      display: block;
      width: 100%;
      margin-bottom: 0;
      padding: 0.5em;
      box-sizing: border-box;
      text-align: center;
    }
    
    #sk-container-id-1 label.sk-toggleable__label-arrow:before {
      /* Arrow on the left of the label */
      content: "▸";
      float: left;
      margin-right: 0.25em;
      color: var(--sklearn-color-icon);
    }
    
    #sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {
      color: var(--sklearn-color-text);
    }
    
    /* Toggleable content - dropdown */
    
    #sk-container-id-1 div.sk-toggleable__content {
      max-height: 0;
      max-width: 0;
      overflow: hidden;
      text-align: left;
      /* unfitted */
      background-color: var(--sklearn-color-unfitted-level-0);
    }
    
    #sk-container-id-1 div.sk-toggleable__content.fitted {
      /* fitted */
      background-color: var(--sklearn-color-fitted-level-0);
    }
    
    #sk-container-id-1 div.sk-toggleable__content pre {
      margin: 0.2em;
      border-radius: 0.25em;
      color: var(--sklearn-color-text);
      /* unfitted */
      background-color: var(--sklearn-color-unfitted-level-0);
    }
    
    #sk-container-id-1 div.sk-toggleable__content.fitted pre {
      /* unfitted */
      background-color: var(--sklearn-color-fitted-level-0);
    }
    
    #sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {
      /* Expand drop-down */
      max-height: 200px;
      max-width: 100%;
      overflow: auto;
    }
    
    #sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
      content: "▾";
    }
    
    /* Pipeline/ColumnTransformer-specific style */
    
    #sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
      color: var(--sklearn-color-text);
      background-color: var(--sklearn-color-unfitted-level-2);
    }
    
    #sk-container-id-1 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
      background-color: var(--sklearn-color-fitted-level-2);
    }
    
    /* Estimator-specific style */
    
    /* Colorize estimator box */
    #sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
      /* unfitted */
      background-color: var(--sklearn-color-unfitted-level-2);
    }
    
    #sk-container-id-1 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
      /* fitted */
      background-color: var(--sklearn-color-fitted-level-2);
    }
    
    #sk-container-id-1 div.sk-label label.sk-toggleable__label,
    #sk-container-id-1 div.sk-label label {
      /* The background is the default theme color */
      color: var(--sklearn-color-text-on-default-background);
    }
    
    /* On hover, darken the color of the background */
    #sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {
      color: var(--sklearn-color-text);
      background-color: var(--sklearn-color-unfitted-level-2);
    }
    
    /* Label box, darken color on hover, fitted */
    #sk-container-id-1 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
      color: var(--sklearn-color-text);
      background-color: var(--sklearn-color-fitted-level-2);
    }
    
    /* Estimator label */
    
    #sk-container-id-1 div.sk-label label {
      font-family: monospace;
      font-weight: bold;
      display: inline-block;
      line-height: 1.2em;
    }
    
    #sk-container-id-1 div.sk-label-container {
      text-align: center;
    }
    
    /* Estimator-specific */
    #sk-container-id-1 div.sk-estimator {
      font-family: monospace;
      border: 1px dotted var(--sklearn-color-border-box);
      border-radius: 0.25em;
      box-sizing: border-box;
      margin-bottom: 0.5em;
      /* unfitted */
      background-color: var(--sklearn-color-unfitted-level-0);
    }
    
    #sk-container-id-1 div.sk-estimator.fitted {
      /* fitted */
      background-color: var(--sklearn-color-fitted-level-0);
    }
    
    /* on hover */
    #sk-container-id-1 div.sk-estimator:hover {
      /* unfitted */
      background-color: var(--sklearn-color-unfitted-level-2);
    }
    
    #sk-container-id-1 div.sk-estimator.fitted:hover {
      /* fitted */
      background-color: var(--sklearn-color-fitted-level-2);
    }
    
    /* Specification for estimator info (e.g. "i" and "?") */
    
    /* Common style for "i" and "?" */
    
    .sk-estimator-doc-link,
    a:link.sk-estimator-doc-link,
    a:visited.sk-estimator-doc-link {
      float: right;
      font-size: smaller;
      line-height: 1em;
      font-family: monospace;
      background-color: var(--sklearn-color-background);
      border-radius: 1em;
      height: 1em;
      width: 1em;
      text-decoration: none !important;
      margin-left: 1ex;
      /* unfitted */
      border: var(--sklearn-color-unfitted-level-1) 1pt solid;
      color: var(--sklearn-color-unfitted-level-1);
    }
    
    .sk-estimator-doc-link.fitted,
    a:link.sk-estimator-doc-link.fitted,
    a:visited.sk-estimator-doc-link.fitted {
      /* fitted */
      border: var(--sklearn-color-fitted-level-1) 1pt solid;
      color: var(--sklearn-color-fitted-level-1);
    }
    
    /* On hover */
    div.sk-estimator:hover .sk-estimator-doc-link:hover,
    .sk-estimator-doc-link:hover,
    div.sk-label-container:hover .sk-estimator-doc-link:hover,
    .sk-estimator-doc-link:hover {
      /* unfitted */
      background-color: var(--sklearn-color-unfitted-level-3);
      color: var(--sklearn-color-background);
      text-decoration: none;
    }
    
    div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
    .sk-estimator-doc-link.fitted:hover,
    div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
    .sk-estimator-doc-link.fitted:hover {
      /* fitted */
      background-color: var(--sklearn-color-fitted-level-3);
      color: var(--sklearn-color-background);
      text-decoration: none;
    }
    
    /* Span, style for the box shown on hovering the info icon */
    .sk-estimator-doc-link span {
      display: none;
      z-index: 9999;
      position: relative;
      font-weight: normal;
      right: .2ex;
      padding: .5ex;
      margin: .5ex;
      width: min-content;
      min-width: 20ex;
      max-width: 50ex;
      color: var(--sklearn-color-text);
      box-shadow: 2pt 2pt 4pt #999;
      /* unfitted */
      background: var(--sklearn-color-unfitted-level-0);
      border: .5pt solid var(--sklearn-color-unfitted-level-3);
    }
    
    .sk-estimator-doc-link.fitted span {
      /* fitted */
      background: var(--sklearn-color-fitted-level-0);
      border: var(--sklearn-color-fitted-level-3);
    }
    
    .sk-estimator-doc-link:hover span {
      display: block;
    }
    
    /* "?"-specific style due to the `<a>` HTML tag */
    
    #sk-container-id-1 a.estimator_doc_link {
      float: right;
      font-size: 1rem;
      line-height: 1em;
      font-family: monospace;
      background-color: var(--sklearn-color-background);
      border-radius: 1rem;
      height: 1rem;
      width: 1rem;
      text-decoration: none;
      /* unfitted */
      color: var(--sklearn-color-unfitted-level-1);
      border: var(--sklearn-color-unfitted-level-1) 1pt solid;
    }
    
    #sk-container-id-1 a.estimator_doc_link.fitted {
      /* fitted */
      border: var(--sklearn-color-fitted-level-1) 1pt solid;
      color: var(--sklearn-color-fitted-level-1);
    }
    
    /* On hover */
    #sk-container-id-1 a.estimator_doc_link:hover {
      /* unfitted */
      background-color: var(--sklearn-color-unfitted-level-3);
      color: var(--sklearn-color-background);
      text-decoration: none;
    }
    
    #sk-container-id-1 a.estimator_doc_link.fitted:hover {
      /* fitted */
      background-color: var(--sklearn-color-fitted-level-3);
    }
    </style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>GridSearchCV(cv=5, estimator=RandomForestRegressor(),
                 param_grid={&#x27;n_estimators&#x27;: [100, 120, 140], &#x27;random_state&#x27;: [42]},
                 scoring=make_scorer(rmsle, greater_is_better=False, response_method=&#x27;predict&#x27;))</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" ><label for="sk-estimator-id-1" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;GridSearchCV<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.model_selection.GridSearchCV.html">?<span>Documentation for GridSearchCV</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>GridSearchCV(cv=5, estimator=RandomForestRegressor(),
                 param_grid={&#x27;n_estimators&#x27;: [100, 120, 140], &#x27;random_state&#x27;: [42]},
                 scoring=make_scorer(rmsle, greater_is_better=False, response_method=&#x27;predict&#x27;))</pre></div> </div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-2" type="checkbox" ><label for="sk-estimator-id-2" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">best_estimator_: RandomForestRegressor</label><div class="sk-toggleable__content fitted"><pre>RandomForestRegressor(n_estimators=140, random_state=42)</pre></div> </div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-3" type="checkbox" ><label for="sk-estimator-id-3" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;RandomForestRegressor<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.ensemble.RandomForestRegressor.html">?<span>Documentation for RandomForestRegressor</span></a></label><div class="sk-toggleable__content fitted"><pre>RandomForestRegressor(n_estimators=140, random_state=42)</pre></div> </div></div></div></div></div></div></div></div></div>



.. code:: ipython3

    print(f'Optimized hyperparameter: {gridsearch_random_forest_model.best_params_}')


.. parsed-literal::

    Optimized hyperparameter: {'n_estimators': 140, 'random_state': 42}
    

.. code:: ipython3

    preds = gridsearch_random_forest_model.best_estimator_.predict(X_train)

.. code:: ipython3

    print(f'RMSLE: {rmsle(log_y_train, preds, True):.4f}')


.. parsed-literal::

    RMSLE: 0.1199
    

.. code:: ipython3

    X_test.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>season</th>
          <th>holiday</th>
          <th>workingday</th>
          <th>weather</th>
          <th>temp</th>
          <th>atemp</th>
          <th>humidity</th>
          <th>year</th>
          <th>day</th>
          <th>hour</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>10886</th>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>10.66</td>
          <td>11.365</td>
          <td>56</td>
          <td>2011</td>
          <td>20</td>
          <td>00</td>
        </tr>
        <tr>
          <th>10887</th>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>10.66</td>
          <td>13.635</td>
          <td>56</td>
          <td>2011</td>
          <td>20</td>
          <td>01</td>
        </tr>
        <tr>
          <th>10888</th>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>10.66</td>
          <td>13.635</td>
          <td>56</td>
          <td>2011</td>
          <td>20</td>
          <td>02</td>
        </tr>
        <tr>
          <th>10889</th>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>10.66</td>
          <td>12.880</td>
          <td>56</td>
          <td>2011</td>
          <td>20</td>
          <td>03</td>
        </tr>
        <tr>
          <th>10890</th>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>10.66</td>
          <td>12.880</td>
          <td>56</td>
          <td>2011</td>
          <td>20</td>
          <td>04</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    submission_preds = gridsearch_random_forest_model.best_estimator_.predict(X_test)

.. code:: ipython3

    figure, axes = plt.subplots(ncols=2)
    figure.set_size_inches(10, 4)
    
    sns.histplot(y_train, ax=axes[0])
    axes[0].set_title('Train Data Distribution')
    sns.histplot(np.exp(submission_preds), ax=axes[1])
    axes[1].set_title('Predicted Test Data Distribution')




.. parsed-literal::

    Text(0.5, 1.0, 'Predicted Test Data\xa0Distribution')




.. image:: output_46_1.png


.. code:: ipython3

    sampleSubmission_df['count'] = np.exp(submission_preds)
    sampleSubmission_df.to_csv('submission.csv', index=False)

